import numpy as np
import math
import particles as par

    
def trans(x,y):
    global r
    global th
    r = np.sqrt(x**2+y**2)
    th = math.degrees(math.atan(y/x))
    print(r,th)
    
def trans_all(): 
    global z_t
    z_t=np.empty((0,2))
    
    for i in range(0,int(par.z.size/2),1):
        x = par.z[i,0]
        y = par.z[i,1]
        trans(x,y)
        z_t=np.append(z_t,np.array([[r,th]]),axis=0)
        
    avg_r=np.mean(z_t[:,0])
    avg_th=np.mean(z_t[:,1])
    std_r=np.std(z_t[:,0])
    std_th=np.std(z_t[:,1])
#     print(z_t)
#     print('-----------------------')
#     print(par.z)
    print("r 평균     : ",avg_r)
    print("r 표준편차 : ",std_r)
    print("th 평균    :",avg_th)
    print("th 표준편차:",std_th)